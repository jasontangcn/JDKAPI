The following assumes you are using JDK 1.3 and the files were extracted to
the d:\JaasExample directory. You will save some work by extracting the files
to this directory otherwise you will have to modify the policy and the ResourceSecurity.xml
policy files with the correct path names.

1) Copy the jaas.jar and the jaasmod.jar to your JDK jre\lib\ext directory
(i.e. D:\JDK1.3\jre\lib\ext).

2) Add the following to the end of the java.security file located in JDK's 
jre\lib\security directory (i.e. D:\JDK1.3\jre\lib\security):
auth.policy.provider=com.ibm.resource.security.auth.XMLPolicyFile

3) Execute the run.bat file.
